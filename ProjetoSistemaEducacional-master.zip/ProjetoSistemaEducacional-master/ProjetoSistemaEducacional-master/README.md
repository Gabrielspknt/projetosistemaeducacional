# Projeto Sistema Educacional
Projeto de um sistema voltado para as escolas
