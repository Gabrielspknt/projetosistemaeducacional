function darkThisPage(){
    const darkmode =  new Darkmode();
    darkmode.toggle();
}


//Dropdown

const elemsDropdown = document.querySelectorAll(".dropdown-trigger");
const instancesDropdown = M.Dropdown.init(elemsDropdown, {
    coverTrigger: true,
    alignment: 'right',
});


